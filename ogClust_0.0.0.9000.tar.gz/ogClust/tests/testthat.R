library(testthat)
library(ogClust)

test_check("ogClust")
